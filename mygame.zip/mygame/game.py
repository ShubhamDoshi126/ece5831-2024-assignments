import draw

def play_game():
    print("Game logic here")

def main():
    play_game()
    draw.draw_game()

if __name__ == "__main__":
    main()