def draw_game():
    print("Drawing the game screen")